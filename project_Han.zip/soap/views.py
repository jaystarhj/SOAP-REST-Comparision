# view
from django.views.decorators.csrf import csrf_exempt

from spyne import Application, rpc, ServiceBase, Iterable, Integer, Unicode, ComplexModel
from spyne.protocol.soap import Soap11, Soap12
from spyne.server.django import DjangoApplication
from rest.controller import get, getById, put, post, delete


class CountryEntry(ComplexModel):
    country_id = Integer
    name = Unicode
    capital = Unicode
    currency = Unicode

    def __init__(self, country_id, name, capital, currency):
        super(CountryEntry, self).__init__()
        self.country_id = country_id
        self.name = name
        self.capital = capital
        self.currency = currency


# 定义一个class类用于之后渲染至django的url
class SIInterfaceForADC(ServiceBase):
    # rpc 为装饰器用于接收参数 _returns 之前的为接收参数,可以为多个, _returns = 返回参数
    # 函数方法,request为接收的参数,如果@rpc中为多个,request也相对应为多个
    @rpc(Integer, _returns=CountryEntry)
    def getCountryById(self, country_id):
        countryObj = getById(country_id)
        c = CountryEntry(countryObj["id"], countryObj["name"], countryObj["capital"], countryObj["currency"])
        return c

    @rpc(_returns=Iterable(CountryEntry))
    def getAllCountry(self):
        countryObjList = get()
        for countryObj in countryObjList:
            yield CountryEntry(countryObj["id"], countryObj["name"], countryObj["capital"], countryObj["currency"])

    @rpc(Unicode, Unicode, Unicode, _returns=CountryEntry)
    def addCountry(self, name, capital, currency):
        countryObj = post(name, capital, currency)
        return CountryEntry(countryObj["id"], countryObj["name"], countryObj["capital"], countryObj["currency"])

    @rpc(Integer, _returns=CountryEntry)
    def deleteCountry(self, country_id):
        countryObj = delete(country_id)
        return CountryEntry(countryObj["id"], countryObj["name"], countryObj["capital"], countryObj["currency"])

    @rpc(Integer, Unicode, Unicode, Unicode, _returns=CountryEntry)
    def updateCountry(self, country_id, name, capital, currency):
        countryObj = put(country_id, name, capital, currency)
        return CountryEntry(countryObj["id"], countryObj["name"], countryObj["capital"], countryObj["currency"])


"""
Application = spyne内置函数,用于将上面定义的类分发起来
SIInterfaceForADC = 定义的类
tns = 代码头定义的tns(暂时没发现实质性作用)
name = 给该类命名
in_protocol = 输入的数据 Soap12 = soap协议,可以为Soap11 validator = 数据类型(一般为lxml)
out_protocol = 输出的数据

"""
application = Application([SIInterfaceForADC], tns="country.soap.ws.api",
                          in_protocol=Soap11(validator='lxml'),
                          out_protocol=Soap11())
# si_service_app = 将spyne渲染至django的url 
si_service_app = csrf_exempt(DjangoApplication(application))
