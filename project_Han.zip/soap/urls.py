from django.urls import path
from spyne.server.django import DjangoView

from . import views

urlpatterns = [
    path('', views.si_service_app)
]

