from django.urls import path

from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('country/all', views.getAll, name='getAll'),
    path('country/<int:id_>', views.rUD, name='rUD'),
    path('country', views.create, name='create'),
    path('mock', views.createDemoData, name='mock'),  # only use once

]

