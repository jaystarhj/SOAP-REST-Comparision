from django.shortcuts import render
from django.core import serializers
# Create your views here.
from django.http import HttpResponse
from .controller import get, post, put, delete, getById
from .models import Country
import json
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt


def index(request):
    return HttpResponse("Hello SOAP")


@csrf_exempt
def getAll(request):
    allItems = get()
    return JsonResponse(allItems, safe=False)

@csrf_exempt
def create(request):
    if request.method == "POST":
        data = json.loads(request.body)
        name, capital, currency = None, None, None
        if "name" in data:
            name = data['name']
        if "capital" in data:
            capital = data['capital']
        if "currency" in data:
            currency = data['currency']
        changedItem = post(name=name, capital=capital, currency=currency)
        return JsonResponse(changedItem, safe=False)


@csrf_exempt
def rUD(request, id_):

    if request.method == "GET":
        allItems = getById(id_)
        return JsonResponse(allItems, safe=False)

    if request.method == "PUT":
        data = json.loads(request.body)
        name, capital, currency = None, None, None

        if "name" in data:
            name = data['name']
        if "capital" in data:
            capital = data['capital']
        if "currency" in data:
            currency = data['currency']
        changedItem = put(id_, name=name, capital=capital, currency=currency)
        return JsonResponse(changedItem, safe=False)

    if request.method == "DELETE":
        changedItem = delete(id_=id_)
        return JsonResponse(changedItem, safe=False)


@csrf_exempt
def createDemoData(request):
    product_list_to_insert = list()
    for x in range(10):
        product_list_to_insert.append(Country(name='USA' + str(x), currency="USD" + str(x), capital="X" + str(x)))
    Country.objects.bulk_create(product_list_to_insert)
    return JsonResponse({"status": "ok"}, safe=False)
