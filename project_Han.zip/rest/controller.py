from .models import Country
from django.forms.models import model_to_dict


def get():
    allItems = Country.objects.all()
    results = []
    for obj in allItems:
        newObj = model_to_dict(obj, fields=[field.name for field in obj._meta.fields])
        results.append(newObj)
    return results


def getById(id_):
    obj = Country.objects.get(pk=id_)
    return model_to_dict(obj, fields=[field.name for field in obj._meta.fields])


def put(id_, name=None, capital=None, currency=None):
    obj = Country.objects.get(pk=id_)
    if name:
        obj.name = name
    if capital:
        obj.capital = capital
    if currency:
        obj.currency = currency
    obj.save()
    return model_to_dict(obj, fields=[field.name for field in obj._meta.fields])


def post(name, capital, currency):
    obj = Country(name=name, capital=capital, currency=currency)
    obj.save()
    return model_to_dict(obj, fields=[field.name for field in obj._meta.fields])


def delete(id_):
    obj = Country.objects.get(pk=id_)
    obj.delete()
    return model_to_dict(obj, fields=[field.name for field in obj._meta.fields])

